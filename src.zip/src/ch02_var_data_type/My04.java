package ch02_var_data_type;

public class My04 {

	public static void main(String[] args) {
		// 문자를 숫자로
		char ch = 'A';
		int code = ch;
		
		System.out.println(ch);		//A
		System.out.println(code);	//65
		
		
		char ch2 = 66;
		System.out.println(ch2); 	//B
		
	}

}
