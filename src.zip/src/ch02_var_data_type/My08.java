package ch02_var_data_type;

public class My08 {

	public static void main(String[] args) {
		/*
		 
		 불리언(boolean) 타입이란?
		 논리값(logical value)을 표현하는 데이터 타입
		 가질 수 있는 값은 true 또는 false 딱 두 가지
		 조건 판단에 사용됨
		 
		 */
		boolean stop = false;
		if(stop) {
			System.out.println("중지합니다");
		} else {
			System.out.println("시작합니다");
		}
	}

}
