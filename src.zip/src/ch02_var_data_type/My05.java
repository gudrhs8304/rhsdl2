package ch02_var_data_type;

public class My05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* 문자열 표현 */
		char single = '\'';
		String dblQuote = "\"Hello\"";
		String root = "c:\\";
		
		System.out.println(single);
		System.out.println(dblQuote);
		System.out.println(root);		// c:\
	}

}
