package ch01;

public class Test02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String b = "오전8시50분";
		
		System.out.println(b);
		System.out.println();
		
		String a = "삼각김밥"; // 문장(문자열)을 메모리(컴퓨터의 저장공간)에 저장.
		// 자료형 변수명(저장장소이름) = 저장할 데이터
		
		System.out.println(a);
		System.out.println();
		System.out.println();
		System.out.println(a);


		// 1. 프로그램은 줄 단위로 위에서 아래로 실행.
		// 2. 한 줄이 실행되고 다음 줄로 이동을 하면, 이전 줄의 데이터를 기억을 할 수 없음.
		// 3. 이전 줄의 내용을 저장하고 싶을 때는 변수에 저장.
	}

}
