package ch01;

public class Comment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 만든 날짜 : 250325
		// 한줄 주석
		/*
		 여러줄 주석
		 */
		
		/*
		 주석 : 코드 내에 작성된 설명문으로, 프로그램 실행에는 영향을 미치지않는 텍스트.
		 1. 코드설명
		 -> 복잡한 로직이나 함수의 역할을 설명하여 자신이나 다른 사람이 이해하기 쉽게 함.
		 2. 메모나 TODO 작성
		 -> 나중에 해야 할 작업이나 아이디어를 기록할 때 사용.
		 3. 디버깅용으로 코드 임시 비활성화
		 -> 특정 코드를 일시적으로 실행되지 않게 하여 문제를 추적할 때 유용.
		 
		 */
		System.out.print("김형곤");
	}

}
