package ch01;

public class Ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* 다음 조건을 만족하는 프로그램을 작성하세요.

		조건:
	    - 두 개의 문자열 변수에 각각 “A: 안녕?“과 “B: 안녕! 잘 지냈어?“를 저장하세요.
		- 각 문장을 줄 바꿈하여 출력하세요.
		
		출력 예시:
		A: 안녕?
		B: 안녕! 잘 지냈어?
		*/
		
		String a = "A : 안녕?";
		String b = "B : 안녕! 잘 지냈어?";
		
		System.out.println(a);
		System.out.println(b);
	}

}
