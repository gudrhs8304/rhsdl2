package ch01;

public class Ex03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*다음 조건을 만족하는 프로그램을 작성하세요.
		조건:
 		“자바는 “ / “정말 “ / “재미있는 언어입니다!” 라는 세 문장을 각각 문자열 변수로 선언합니다.
      	
      	세 문장을 이어붙여서 한 줄로 출력하세요.
		
		출력 예시:
		자바는 정말 재미있는 언어입니다!
		*/
		
		String a = "자바는 ";
		String b = "정말 ";
		String c = "재미있는 언어입니다!";
		
		System.out.print(a);
		System.out.print(b);
		System.out.print(c);
		
		System.out.println();
		
		System.out.print(a+b+c);
	}

}
