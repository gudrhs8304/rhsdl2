package test;

public class Test01 {
    public static void main(String[] args) {
        String msg = "Hello Java!!!";
        System.out.println(msg);
    }
}
